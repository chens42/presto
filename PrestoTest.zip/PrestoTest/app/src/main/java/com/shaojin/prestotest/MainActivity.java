package com.shaojin.prestotest;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnFocusChangeListener {

    private EditText creditCardNumber;
    private EditText expirationDate;
    private EditText cvv;
    private EditText firstName;
    private EditText lastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        creditCardNumber = findViewById(R.id.creditCardNumber);
        expirationDate = findViewById(R.id.expirationDate);
        cvv = findViewById(R.id.cvv);
        firstName = findViewById(R.id.firstName);
        lastName = findViewById(R.id.lastName);
        Button button = findViewById(R.id.submitButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg;
                if (isPassValidation(creditCardNumber)
                        && isPassValidation(expirationDate)
                        && isPassValidation(cvv)
                        && isPassValidation(firstName)
                        && isPassValidation(lastName)) {
                    msg = "Input Successful.";
                } else {
                    msg = "Something wrong with credit cardInfo";
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage(msg)
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //do things
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
        creditCardNumber.setOnFocusChangeListener(this);
        expirationDate.setOnFocusChangeListener(this);
        cvv.setOnFocusChangeListener(this);
        firstName.setOnFocusChangeListener(this);
        lastName.setOnFocusChangeListener(this);
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (!hasFocus && !isPassValidation(v)) {
            Toast.makeText(getApplicationContext(), "Warning : Field :" + ((EditText) v).getHint() + " is't valid", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPassValidation(View view) {
        String input = ((EditText) view).getText().toString();
        switch (view.getId()) {
            case R.id.expirationDate:
                return expirationCheck(input);
            case R.id.creditCardNumber:
                return creditCardNumberCheck(input);
            case R.id.cvv:
                return cvvCheck(input);
            case R.id.firstName:
                return firstNameCheck(input);
            case R.id.lastName:
                return lastNameCheck(input);
        }
        return true;
    }

    private boolean expirationCheck(String expirationDate) {
        if (expirationDate.length() != 5)
            return false;
        String pattern = "(0[1-9]|10|11|12)/[0-9]{2}$";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(expirationDate);
        return m.find();
    }

    private boolean creditCardNumberCheck(String creditCardNumber) {
        try {
            new BigInteger(creditCardNumber);
        } catch (NumberFormatException | NullPointerException nfe) {
            return false;
        }
        switch (creditCardNumber.length()) {
            case 15:
                return creditCardNumber.startsWith("34") || creditCardNumber.startsWith("37");
            case 16:
                int convertedInteger;
                try {
                    convertedInteger = Integer.parseInt(creditCardNumber.substring(0, 6));
                } catch (NumberFormatException | NullPointerException nfe) {
                    return false;
                }
                if ((convertedInteger >= 601100 && convertedInteger <= 601109)
                        || (convertedInteger >= 601120 && convertedInteger <= 601149)
                        || convertedInteger == 601174
                        || (convertedInteger >= 601177 && convertedInteger <= 601179)
                        || (convertedInteger >= 601186 && convertedInteger <= 601199)
                        || (convertedInteger >= 644000 && convertedInteger <= 659999)) {
                    return true;
                }
                return (convertedInteger >= 510000 && convertedInteger <= 559999)
                        || (convertedInteger >= 222100 && convertedInteger <= 272099);
            case 19:
                return creditCardNumber.startsWith("4");
        }
        return false;
    }

    private boolean cvvCheck(String cvv) {
        Pattern p = Pattern.compile("^\\d{3,4}$");
        Matcher m = p.matcher(cvv);
        return m.find();
    }

    private boolean firstNameCheck(String firstName) {
        Pattern p = Pattern.compile("^[ A-Za-z]+$");
        Matcher m = p.matcher(firstName);
        return m.matches();
    }

    private boolean lastNameCheck(String lastName) {
        Pattern p = Pattern.compile("^[ A-Za-z]+$");
        Matcher m = p.matcher(lastName);
        return m.matches();
    }
}
