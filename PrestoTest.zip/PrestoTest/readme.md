1. I created activity_main.xml with 5 EditText views and a button.

2. I used string resource to get the predefined text for EditText hint. The reason why I did that is that it will be easy to maintain the application in the future(if need). For example, if the application needs to be developed to support multiple languages, I won't need to go through the entire project to change all the text. 

3. In MainActivity.java, I registered "OnFocusChangeListener" for every EditTexts. When the EditText View is unfocused(finished typing), It will check if the input data is validated. It will Toast an error message.



4. When the user clicked on the "submit" button, it will perform entire testes again. If all input data meet those requirements, it will show a dialog with the message "Input Successful.". "Something wrong with credit cardInfo" otherwise.



5. Since I check the data in two places, I created "isPassValidation(View view)" method for the code re-using.